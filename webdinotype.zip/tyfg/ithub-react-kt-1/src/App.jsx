import SectionServices from "./components/section-services/SectionServices"
import SectionHeader from "./components/section-header/SectionHeader"
import SectionRent from "./components/section-rent/SectionRent"
import SectionGlob from "./components/section-glob/SectionGlob"
import SectionGebe from "./components/section-gebe/SectionGebe"


function App() {
  return (
    <>
      <SectionHeader />
      <SectionGlob />
      <SectionGebe />
      <SectionServices />
      <SectionRent />
    </>
  )
}

export default App

import classes from './SectionGlob.module.css'
import image1 from '../../assets/image1.jpg'
export default function SectionGlob() {
    return (
        <nav className={classes.services}>
            <section id="glob">

                <img src={image1} alt="bike image" className={classes.ehu} />
                <div>
                    <h2 className={classes.hi}>Что мы предлагаем</h2>
                    <div className={classes.hi1}>
                        <p>В нашей мастерской можно выполнить</p>
                        <p>комплексное техническое обслуживание</p>
                        <p>велосипеда, ремонт и настройку всех его узлов,</p>
                        <p>шиномонтажные работы. Вовремя проведенное</p>
                        <p>ТО велосипеда помогает избежать многих</p>
                        <p>проблем и дорогого ремонта.  Все работы</p>
                        <p>выполняем качественно и с душой.</p>
                    </div>
                </div>
            </section>
        </nav>
    )
}


import classes from './SectionGebe.module.css'
export default function SectionGebe() {
    return (
        <nav className={classes.services}>
            <section id="gebe">
                <div>
                    <p className={classes.hi}>Приехав к нам однажды, многие наши клиенты становятся</p>
                    <p className={classes.hi}>постоянными, а часть из них даже друзьями.</p>
                    <div className={classes.hi1}>
                        <p>А также в нашей мастерской можно отремонтировать</p>
                        <p>электросамокат и электровелосипед.</p>
                    </div>
                </div>
            </section>
        </nav>
    )
}


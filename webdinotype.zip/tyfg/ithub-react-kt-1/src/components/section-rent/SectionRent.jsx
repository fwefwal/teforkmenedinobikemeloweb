import image2 from '../../assets/image2.jpg'
import classes from './SectionRent.module.css'

export default function SectionRent() {
    return (
        <nav className={classes.header}>
            <section id="rent">

                <img src={image2} alt="bike image" />

                <div>
                    <h2 className={classes.hi}>Прокат велосипедов</h2>
                    <div className={classes.hi1}>
                        <p>У нас вы можете взять на прокат</p>
                        <p>хорошо обслуженные и настроенные</p>
                        <p>велосипеды. Как раз мы находимся в</p>
                        <p>прекрасном парке!</p></div>
                </div>

            </section>
        </nav>
    )
}


import classes from './SectionHeader.module.css'

export default function SectionHeader() {
    return (
        <header className={classes.header}>
            <nav className={classes.header__nav}>
                <img src="/logo.png" alt="логотип велозар" className="header__logo" />
                <ul className="links">
                    <li className="link">
                        <a href="#about" className={classes.hjk1}>О нас</a>
                    </li>
                    <li className="link">
                        <a href="#services" className={classes.hjk2}>Услуги</a>
                    </li>
                    <li className="link">
                        <a href="#rent" className={classes.hjk3}>Аренда</a>
                    </li>
                </ul>
                <button className={classes.btn}>Связаться</button>
            </nav>
            <div className='header__content' >
                <h1 className={classes.header__brand}>Веломастерская “Велозар”</h1>
                <div className={classes.uuu}>
                    <p>Мы, мастера веломастерской «Велозар», как раз</p>
                    <p>те самые счастливые люди, которые смогли</p>
                    <p>превратить свое увлечение и хобби в профессию.</p>
                    <p> Мы сами любим кататься и хотим чтобы </p>
                    <p>Ваш двухколесный друг приносил Вам только радость</p>
                    <p>и удовольствие от езды.</p>
                </div>

                <img src="/mascotte.png" alt="маскот велозар" className={classes.header__logl} />
            </div>
        </header>
    )
}